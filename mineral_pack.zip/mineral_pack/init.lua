local path = minetest.get_modpath("mineral_pack")

dofile(path.."/armor.lua")
dofile(path.."/blocks.lua")
dofile(path.."/items.lua")
dofile(path.."/ores.lua")
dofile(path.."/tools.lua")
dofile(path.."/crafting.lua")