minetest.register_craftitem("mineral_pack:cobalt_ingot", {
	description = "Cobalt ingot",
	inventory_image = "mineral_pack_cobalt_ingot.png",
})
minetest.register_craftitem("mineral_pack:cobalt_nugget", {
	description = "Cobalt nugget",
	inventory_image = "mineral_pack_cobalt_nugget.png",
})
minetest.register_craftitem("mineral_pack:nickel_ingot", {
	description = "Nickel ingot",
	inventory_image = "mineral_pack_nickel_ingot.png",
})
minetest.register_craftitem("mineral_pack:nickel_nugget", {
	description = "Nickel nugget",
	inventory_image = "mineral_pack_nickel_nugget.png",
})
minetest.register_craftitem("mineral_pack:amethyst_fragment", {
	description = "Amethyst fragment",
	inventory_image = "mineral_pack_amethyst_fragment.png",
})
minetest.register_craftitem("mineral_pack:spinel_fragment", {
	description = "Spinel fragment",
	inventory_image = "mineral_pack_spinel_fragment.png",
})
minetest.register_craftitem("mineral_pack:topaz_fragment", {
	description = "Topaz fragment",
	inventory_image = "mineral_pack_topaz_fragment.png",
})
minetest.register_craftitem("mineral_pack:ruby_fragment", {
	description = "Ruby fragment",
	inventory_image = "mineral_pack_ruby_fragment.png",
})
minetest.register_craftitem("mineral_pack:sapphire_fragment", {
	description = "Sapphire fragment",
	inventory_image = "mineral_pack_sapphire_fragment.png",
})
minetest.register_craftitem("mineral_pack:emerald_fragment", {
	description = "Emerald fragment",
	inventory_image = "mineral_pack_emerald_fragment.png",
})
minetest.register_craftitem("mineral_pack:titanium_ingot", {
	description = "Titanium ingot",
	inventory_image = "mineral_pack_titanium_ingot.png",
})
minetest.register_craftitem("mineral_pack:titanium_nugget", {
	description = "Titanium nugget",
	inventory_image = "mineral_pack_titanium_nugget.png",
})
minetest.register_craftitem("mineral_pack:osmium_ingot", {
	description = "Osmium ingot",
	inventory_image = "mineral_pack_osmium_ingot.png",
})
minetest.register_craftitem("mineral_pack:osmium_nugget", {
	description = "Osmium nugget",
	inventory_image = "mineral_pack_osmium_nugget.png",
})
minetest.register_craftitem("mineral_pack:platinum_ingot", {
	description = "Platinum ingot",
	inventory_image = "mineral_pack_platinum_ingot.png",
})
minetest.register_craftitem("mineral_pack:platinum_nugget", {
	description = "Platinum nugget",
	inventory_image = "mineral_pack_platinum_nugget.png",
})
minetest.register_craftitem("mineral_pack:aluminum_ingot", {
	description = "Aluminum ingot",
	inventory_image = "mineral_pack_aluminum_ingot.png",
})
minetest.register_craftitem("mineral_pack:aluminum_nugget", {
	description = "Aluminum nugget",
	inventory_image = "mineral_pack_aluminum_nugget.png",
})